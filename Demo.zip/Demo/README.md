# Jarvis March

This a P5.js implementation of Jarvis March (Gift wrapping algorithm) that is used to compute the convex hull of a set of points.

https://en.wikipedia.org/wiki/Gift_wrapping_algorithm
