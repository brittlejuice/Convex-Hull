/**
 * Represents the Jarvis March algorithm for computing the convex hull of a set of points.
 * This version exposes all previously private variables as public properties.
 * The time complexity of the algorithm is O(n^2)
 */
class JarvisMarch {
    /**
     * Constructs an instance of the JarvisMarch algorithm with a set of points.
     * Initializes global variables required for the algorithm.
     * @param {Object[]} points - An array of points where each point is an object with xCoor and yCoor properties.
     */
    constructor(points) {
        this.points = points;
        this.numPts = points.length;
        this.hullPoints = [];
        this.currHullIndex = 0;
        this.pointIndex = 0;
        this.bestAngle = 0;
        this.bestPoint = -1;
        this.prevPt = null;
    }

    /**
     * Executes one step of the Jarvis March algorithm, incrementally adding points to the convex hull.
     */
    run() {
        if (this.hullPoints.length === 0) {
            let left = this.leftMost();
            this.hullPoints.push(this.points[left]);
        }

        if (this.bestPoint > -1) {
            let p1 = this.hullPoints[this.hullPoints.length - 1];
            let p2 = this.points[this.bestPoint];
            // Assuming `strokeWeight`, `stroke`, and `line` are defined elsewhere
            strokeWeight(3);
            stroke("black");
            line(p1.xCoor, p1.yCoor, p2.xCoor, p2.yCoor);
        }

        if (this.currHullIndex === 0) {
            this.prevPt = { xCoor: this.hullPoints[this.currHullIndex].xCoor, yCoor: 0 };
        } else {
            this.prevPt = {
                xCoor: this.hullPoints[this.currHullIndex - 1].xCoor,
                yCoor: this.hullPoints[this.currHullIndex - 1].yCoor,
            };
        }

        let angle = this.getAngle(this.prevPt, this.hullPoints[this.currHullIndex], this.points[this.pointIndex]);

        if (angle > this.bestAngle) {
            this.bestAngle = angle;
            this.bestPoint = this.pointIndex;
        }

        this.pointIndex++;
        if (this.pointIndex >= this.points.length) {
            this.hullPoints.push(this.points[this.bestPoint]);
            if (this.hullPoints[0] === this.hullPoints[this.hullPoints.length - 1]) {
                // Some logic to terminate the algorithm
            }

            this.currHullIndex++;
            this.pointIndex = 0;
            this.bestPoint = -1;
            this.bestAngle = 0;
        }
    }

    /**
     * Displays the convex hull by drawing lines between points in the hull.
     */
    displayHull() {
        // Similar to the original `displayHull` method
    }

    /**
     * Draws the original set of points.
     */
    drawPoints() {
        // Similar to the original `drawPoints` method
    }

    /**
     * Calculates the angle between three points using the Law of Cosines.
     * smaller cosine means a larger angle
     * @param {Object} prevPt - The previous point in the hull.
     * @param {Object} hullPt - The current point in the hull.
     * @param {Object} nextPt - The candidate next point.
     * @returns {number} The angle in radians.
     */
    getAngle(prevPt, hullPt, nextPt) {
        // Implementation similar to the original `getAngle`
    }

    /**
     * Finds the leftmost point from the set of points.
     * this point is used as the starting point of the algorithm,according to the x coordinate
     * @returns {number} The index of the leftmost point.
     */
    leftMost() {
        // Implementation similar to the original `leftMost`
    }
}
