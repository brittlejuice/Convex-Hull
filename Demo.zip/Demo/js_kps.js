const L = 500;

const EPSILON = 1e-9;

let demonstration = [];

function AreSame(a, b) {
    return Math.abs(a - b) < EPSILON
}
function MOM_kth_smallest_ld(A, siz, k) {
    if (siz <= 2 * L) {
        A.sort(function (a, b) { return a - b })
        return A[k];
    }
    let medians = [];
    for (let i = 0; i < siz;) {
        let start = i;
        let stop = i + L;
        if (stop > siz) stop = siz;
        A.slice(start, stop).sort();
        medians.push(A[start + Math.floor((stop - start) / 2)]);
        i += L;
    }
    let MOM = MOM_kth_smallest_ld(medians, medians.length, Math.floor(medians.length / 2));
    let less_than_eq_to_MOM_array = [];
    let greater_than_MOM_array = [];
    for (let i = 0; i < siz; i++) {
        if (A[i] <= MOM) less_than_eq_to_MOM_array.push(A[i]);
        else greater_than_MOM_array.push(A[i]);
    }
    if (less_than_eq_to_MOM_array.length > k) return MOM_kth_smallest_ld(less_than_eq_to_MOM_array, less_than_eq_to_MOM_array.length, k);
    else return MOM_kth_smallest_ld(greater_than_MOM_array, greater_than_MOM_array.length, k - less_than_eq_to_MOM_array.length);
}

function MOM_kth_smallest(A, siz, k) {
    if (siz <= 2 * L) {
        A.sort(function (a, b) { return a - b })
        console.log(A);
        return A[k];
    }
    var medians = [];
    for (var i = 0; i < siz;) {
        var start = i;
        var stop = i + L;
        if (stop > siz) stop = siz;
        A.slice(start, stop).sort();
        medians.push(A[start + Math.floor((stop - start) / 2)]);
        i += L;
    }
    var MOM = MOM_kth_smallest(medians, medians.length, Math.floor(medians.length / 2));
    var less_than_eq_to_MOM_array = [];
    var greater_than_MOM_array = [];
    for (var i = 0; i < siz; i++) {
        if (A[i] <= MOM) less_than_eq_to_MOM_array.push(A[i]);
        else greater_than_MOM_array.push(A[i]);
    }
    if (less_than_eq_to_MOM_array.length > k) return MOM_kth_smallest(less_than_eq_to_MOM_array, less_than_eq_to_MOM_array.length, k);
    else return MOM_kth_smallest(greater_than_MOM_array, greater_than_MOM_array.length, k - less_than_eq_to_MOM_array.length);
}

function pos_0_neg(point, x, y) {
    var val = (point.x - x[0]) * (y[1] - x[1]) - (point.y - x[1]) * (y[0] - x[0]);
    return val;
}
function pos_0_neg_idk_bitch(point, x, y) {
    var val = (point[0] - x[0]) * (y[1] - x[1]) - (point[1] - x[1]) * (y[0] - x[0]);
    return val;
}
function find_y_intercept(slope, x) {
    return x[1] - slope * x[0];
}

function UPPER_BRIDGE(T, xmedian) {
    let candidates = [];
    if (T.length === 2) {
        if (T[0][0] < T[1][0]);
        else[T[0], T[1]] = [T[1], T[0]];
        return [T[0], T[1]];
    }
    let paired_points = [];
    for (let i = 0; i < T.length;) {
        if (i === T.length - 1) {
            candidates.push(T[i]);
            break;
        }
        let a = T[i], b = T[i + 1];
        if (b[0] < a[0])
            paired_points.push([b, a]);
        else
            paired_points.push([a, b]);
        i += 2;
    }
    let nissi = []
    nissi.push(4)
    nissi.push(paired_points);
    demonstration.push(nissi);
    let slopes = [];
    for (let x of paired_points) {
        if (x[0][0] === x[1][0]) {
            if (x[0][1] > x[1][1]) candidates.push(x[0]);
            else candidates.push(x[1]);
        }
        else {
            slopes.push((x[1][1] - x[0][1]) / (x[1][0] - x[0][0]));
        }
    }
    console.log(paired_points);
    let slope_median = MOM_kth_smallest_ld(slopes.slice(), slopes.length, Math.floor(slopes.length / 2));
    console.log(slopes);
    console.log(typeof (slope_median));
    console.log(typeof (slopes[0]));
    console.log(slope_median);
    let small = [], equal = [], large = [];
    for (let i = 0; i < slopes.length; i++) {
        if (slopes[i] === slope_median) equal.push(paired_points[i]);
        else if (slopes[i] > slope_median) large.push(paired_points[i]);
        else small.push(paired_points[i]);
    }

    console.log(equal);
    console.log(small);
    console.log(large);
    let max_y_intercept = -1e9;
    for (let x of T) {
        let y_intercept = find_y_intercept(slope_median, x);
        if (max_y_intercept < y_intercept) {
            max_y_intercept = y_intercept;
        }
    }
    let pk = [1e9, 1e9], pm = [-1e9, -1e9];
    for (let x of T) {
        let y_intercept = find_y_intercept(slope_median, x);
        if (AreSame(max_y_intercept, y_intercept)) {
            if (pk[0] >= x[0]) pk = x;
            if (pm[0] <= x[0]) pm = x;
        }
    }
    let nissi3 = [];
    nissi3.push(6);
    nissi3.push(slope_median);
    nissi3.push(pk);
    nissi3.push(pm);
    demonstration.push(nissi3);
    if (pk[0] <= xmedian && pm[0] > xmedian) {
        return [pk, pm];
    }
    if (pm[0] <= xmedian) {
        for (let x of equal) candidates.push(x[1]);
        for (let x of large) candidates.push(x[1]);
        for (let x of small) {
            candidates.push(x[0]);
            candidates.push(x[1]);
        }
    }
    if (pk[0] > xmedian) {
        for (let x of equal) candidates.push(x[0]);
        for (let x of small) candidates.push(x[0]);
        for (let x of large) {
            candidates.push(x[0]);
            candidates.push(x[1]);
        }
    }
    console.log("candidates are ");
    console.log(candidates);
    let nissi2 = [];
    nissi2.push(5);
    nissi2.push(paired_points);
    demonstration.push(nissi2);
    return UPPER_BRIDGE(candidates, xmedian);
}

function UPPER_HULL(pmin, pmax, T, n) {
    let T_vi = [];
    for (let x of T) {
        T_vi.push(x[0]);
    }
    let xmedian = MOM_kth_smallest(T_vi, n, Math.floor(n / 2));
    let nissi = [];
    nissi.push(2)
    nissi.push(xmedian);
    demonstration.push(nissi);
    console.log(xmedian);
    let if_less_than_2_size = [pmin];
    if (T.length == 1) {
        let nissi2 = [];
        nissi2.push(3);
        nissi2.push(xmedian);
        demonstration.push(nissi2)
        return if_less_than_2_size;
    }
    if_less_than_2_size.push(pmax);
    if (T.length == 2) {
        let nissi = [];
        nissi.push(7);
        nissi.push(T);
        demonstration.push(nissi);
        let nissi2 = [];
        nissi2.push(3);
        nissi2.push(xmedian);
        demonstration.push(nissi2);
        return if_less_than_2_size;
    }
    let pl_pr = UPPER_BRIDGE(T, xmedian);
    let nissi3 = [];
    nissi3.push(7);
    nissi3.push(pl_pr);
    demonstration.push(nissi3);




    let nissi2 = [];
    nissi2.push(3);
    nissi2.push(xmedian);
    demonstration.push(nissi2) // checkkkk......
    let pl = pl_pr[0];
    let pr = pl_pr[1];
    console.log(pl_pr);
    let T_left = [];
    let T_right = [];
    if (pl[0] == pmin[0] && pr[0] == pmax[0]) {
        let edge_case = [pl, pr];
        console.log("ef");
        return edge_case;
    }
    for (let i = 0; i < T.length; i++) {
        if (pl != pmin && T[i][0] <= xmedian && (pos_0_neg_idk_bitch(T[i], pl, pmin) >= 0) && T[i][0] >= pmin[0]) {
            T_left.push(T[i]);
        }
        if (pr != pmax && T[i][0] > xmedian && (pos_0_neg_idk_bitch(T[i], pr, pmax) <= 0) && T[i][0] <= pmax[0]) {
            T_right.push(T[i]);
        }
    }
    let upper_hull_left = [];
    let upper_hull_right = [];
    console.log("Tleft and tright are");
    console.log(T_left);
    console.log(T_right);
    if (T_left.length > 0) {
        upper_hull_left = UPPER_HULL(pmin, pl, T_left, T_left.length);
    }
    if (T_right.length > 0) {
        upper_hull_right = UPPER_HULL(pr, pmax, T_right, T_right.length);
    }
    let upper_hull = [];
    for (let x of upper_hull_left) {
        upper_hull.push(x);
    }
    if (upper_hull[upper_hull.length - 1] != pr) upper_hull.push(pr);
    for (let x of upper_hull_right) {
        upper_hull.push(x);
    }
    return upper_hull;
}
function onlyUnique(value, index, array) {
    return array.indexOf(value) === index;
}
function CONVEX_HULL(A, n) {
    let xmin = 1e9, xmax = -1e9;
    for (let i = 0; i < n; i++) {
        xmin = Math.min(xmin, A[i].x);
        xmax = Math.max(xmax, A[i].x);
    }
    let left_mid_elements = [], right_mid_elements = [];
    let plmin = [xmin, 1e9], plmax = [xmax, 1e9], pumin = [xmin, -1e9], pumax = [xmax, -1e9];
    console.log("ahigtri[ahghpwt4ong;w;u8ru souaiojwih]")
    console.log(xmin)
    for (let i = 0; i < n; i++) {
        if (A[i].x == xmin) {
            plmin[1] = Math.min(plmin[1], A[i].y);
            pumin[1] = Math.max(pumin[1], A[i].y);
            left_mid_elements.push([A[i].x, A[i].y]);
        }
        if (A[i].x == xmax) {
            plmax[1] = Math.min(plmax[1], A[i].y);
            pumax[1] = Math.max(pumax[1], A[i].y);
            right_mid_elements.push([A[i].x, A[i].y]);
        }
    }

    let nissi = []
    nissi.push(1)
    nissi.push(plmin)
    nissi.push(pumin)
    nissi.push(plmax)
    nissi.push(pumax)

    demonstration.push(nissi);

    console.log("plmin is: " + plmin[0] + " " + plmin[1]);
    console.log("plmax is: " + plmax[0] + " " + plmax[1]);
    console.log("pumin is: " + pumin[0] + " " + pumin[1]);
    console.log("pumax is: " + pumax[0] + " " + pumax[1]);
    let T1 = [], T2 = [];
    plmin[1] = -plmin[1];
    let plmin_original_copy = plmin.slice();
    plmin_original_copy[1] = -plmin_original_copy[1];
    T1.push(pumin);
    T2.push(plmin);
    for (let i = 0; i < n; i++) {
        if (A[i].x > xmin && A[i].x < xmax) {
            if (pos_0_neg(A[i], pumax, pumin) >= 0) {
                T1.push([A[i].x, A[i].y]);
            }
            if (pos_0_neg(A[i], plmax, plmin_original_copy) <= 0) {
                console.log(typeof (A[i].x));
                T2.push([A[i].x, -1 * A[i].y]);
                console.log(T2[T2.length - 1]);
            }
        }
    }
    T1.push(pumax);
    plmax[1] = -plmax[1];
    console.log(plmax);
    T2.push(plmax);

    for (let pt of T2) {
        if (pt[1] > 0) {
            pt[1] = -pt[1].valueOf()
        }
    }


    console.log(T1);
    console.log(T2);
    let convex_hull = [];
    let upper_hull = UPPER_HULL(pumin, pumax, T1, T1.length);
    console.log("upper")
    console.log(upper_hull);
    let lower_hull = UPPER_HULL(plmin, plmax, T2, T2.length);
    console.log("upper")
    console.log(upper_hull);
    console.log("lower");
    console.log(lower_hull);
    for (let i = 0; i < lower_hull.length; i++) {
        lower_hull[i][1] = -lower_hull[i][1];
    }
    lower_hull.reverse();
    left_mid_elements.sort((a, b) => a[1] - b[1]);
    right_mid_elements.sort((a, b) => b[1] - a[1]);
    for (let x of left_mid_elements) {
        if (convex_hull.length !== 0 && convex_hull[convex_hull.length - 1] === x);
        else convex_hull.push(x);
    }
    for (let x of upper_hull) {
        if (convex_hull.length !== 0 && convex_hull[convex_hull.length - 1] === x);
        else convex_hull.push(x);
    }
    for (let x of right_mid_elements) {
        if (convex_hull.length !== 0 && convex_hull[convex_hull.length - 1] === x);
        else convex_hull.push(x);
    }
    for (let x of lower_hull) {
        if (convex_hull.length !== 0 && convex_hull[convex_hull.length - 1] === x);
        else convex_hull.push(x);
    }
    if (convex_hull.length !== 0 && convex_hull[0] === convex_hull[convex_hull.length - 1])
        convex_hull.pop();
    console.log(convex_hull)
    // let unique = [...new Set(convex_hull.map(x => x[0]*1000+x[1]))].map(x => [Math.floor(x/1000),x%1000]);

    // console.log(unique); 
    unique = []
    unique.push(convex_hull[0]);
    for (let i = 0; i < convex_hull.length - 1; i++) {
        //if(i===convex_hull.length-2 && (Math.abs(convex_hull[0][0]-convex_hull[i+1][0]) + Math.abs(convex_hull[0][1]-convex_hull[i+1][1])) != 0 && (Math.abs(convex_hull[i][0]-convex_hull[i+1][0]) + Math.abs(convex_hull[i][1]-convex_hull[i+1][1])) != 0)
        if ((Math.abs(convex_hull[i][0] - convex_hull[i + 1][0]) + Math.abs(convex_hull[i][1] - convex_hull[i + 1][1])) != 0) {
            unique.push(convex_hull[i + 1]);
        }
    }
    if ((Math.abs(unique[0][0] - unique[unique.length - 1][0]) + Math.abs(unique[0][1] - unique[unique.length - 1][1])) == 0) unique.pop();
    for (let i = 0; i < unique.length; i++) {
        unique[i][0] = Math.abs(unique[i][0]);
        unique[i][1] = Math.abs(unique[i][1]);
    }
    console.log(unique)
    return [demonstration, unique];
}

function linedraw(ax, ay, bx, by) {
    if (ay > by) {
        bx = ax + bx;
        ax = bx - ax;
        bx = bx - ax;
        by = ay + by;
        ay = by - ay;
        by = by - ay;
    }
    var calc = Math.atan((ay - by) / (bx - ax));
    calc = calc * 180 / Math.PI;
    var length = Math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by));
    document.body.innerHTML += "<div class='line' style='height:" + length + "px;width:1px;background-color:black;position:absolute;top:" + (ay) + "px;left:" + (ax) + "px;transform:rotate(" + calc + "deg);-ms-transform:rotate(" + calc + "deg);transform-origin:0% 0%;-moz-transform:rotate(" + calc + "deg);-moz-transform-origin:0% 0%;-webkit-transform:rotate(" + calc + "deg);-webkit-transform-origin:0% 0%;-o-transform:rotate(" + calc + "deg);-o-transform-origin:0% 0%;'></div>"
}

function findConvexHull(numPoints, points) {
    var n = numPoints;
    n = parseInt(n);
    const A = points;
    A.map((pt) => parseInt(pt))
    console.log("in html");
    console.log(n); console.log(A);
    const X = [];
    for (var i = 0; i < n; i++) {
        X.push(A[i].x);
    }
    X.sort(function (a, b) { return a - b })
    console.log(MOM_kth_smallest(X, X.length, Math.floor(X.length / 2)));
    //let M=MOM_kth_smallest(X,X.length,Math.floor(X.length/2))

    const convex_hull = CONVEX_HULL(A, n);
    for (let i = 0; i < convex_hull.length; i++) {
        console.log(convex_hull[i][0] + " " + convex_hull[i][1]);
    }
    // for (let i = 0; i < convex_hull.length-1; i++) {
    // let point1 = convex_hull[i];
    // let point2 = convex_hull[i+1];
    // // point.classList.add('highlighted');
    // linedraw(point1[0],point1[1],point2[0],point2[1]);

    // // addConvexHullPoint(x,y);
    // }

    return convex_hull;
}